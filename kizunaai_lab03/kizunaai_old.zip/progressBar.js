var getProgressBar = function(){
    
    var wm = new WeakMap();

    function _getVal(obj, key){
        var _obj = wm.get(obj);

        if(typeof _obj == 'undefined'){
            return undefined;
        }
        return _obj[key]; 
    }

    function _setVal(obj, key, value){

        var _obj = wm.get(obj);
        if(typeof _obj == 'undefined'){
            _obj = {};
            wm.set(obj, _obj)
        }
        _obj[key] = value;
    }

    function myProgressBar(){
        var style = [
            "position: absolute;",
            "top: 0%;",
            "height: 100%;",
            "background: rgba(106, 106, 245, 0.616);"
        ].join("");

        var progressBar = document.createElement("div");
        progressBar.style.cssText = style;
        _setVal(this, "progressBar", progressBar);
    }

    myProgressBar.prototype.clear = function(){
        var progressBar = _getVal(this, "progressBar");
        progressBar.style.width = 0;
    }

    myProgressBar.prototype.setProgress = function(progress){
        var progressBar = _getVal(this, "progressBar");
        progressBar.style.width = progress + "%";
    }

    myProgressBar.prototype.remove = function(){
        var progressBar = _getVal(this, "progressBar");
        progressBar.remove();
    }

    myProgressBar.prototype.getElement = function(){
        return _getVal(this, "progressBar");
    }


    function myD3ProgressBar(arg){
        var progressBar = document.createElement("div");

        var height = document.querySelector(arg.el).clientHeight;
        var width = document.querySelector(arg.el).clientWidth;
        _setVal(this, "width", width);

        d3.select(progressBar)
          .style("position", "absolute")
          .style("top", "0%")
          .style("z-index", "-99")

        var svg = d3.select(progressBar)
                    .append("svg")
                    .attr("height", height)
                    .attr("width", width);

        var getStep = function(idx){
            var domain = [0, 20, 40, 60, 80, 100, Infinity];
        
            for(var i = 0 ;i<domain.length; i++){
                if(idx >= domain[i] && idx < domain[i+1]){
                    return domain[i];
                }
            }
        };
        
        var colorRange = d3.scaleOrdinal()
                           .domain(["0", "20", "40", "60", "80", "100"])
                           .range(["#ff4a3d", "#ffb53d", "#3dc5ff", "#3d54ff", "#ab3dff", "#7eff70"]);

        var rect = svg.append("rect")
           .attr("height", height);

        _setVal(this, "rect", rect);
        _setVal(this, "getStep", getStep);
        _setVal(this, "colorRange", colorRange);
        _setVal(this, "progressBar", progressBar);
    }

    myD3ProgressBar.prototype.clear = function(){
        var rect = _getVal(this, "rect");
        rect.attr("width", 0);
    }

    myD3ProgressBar.prototype.setProgress = function(progress){
        var rect = _getVal(this, "rect");
        var getStep = _getVal(this, "getStep");
        var colorRange = _getVal(this, "colorRange");
        var width = _getVal(this, "width");

        rect
          .attr("width", width * (progress / 100))
          .attr("fill", function(){return colorRange(getStep(progress))});
    }

    myD3ProgressBar.prototype.remove = function(){
        var progressBar = _getVal(this, "progressBar");
        progressBar.remove();
    }

    myD3ProgressBar.prototype.getElement = function(){
        return _getVal(this, "progressBar");
    }

    if(
        typeof window.d3 != "undefined" && 
        typeof window.d3.version == "string" &&
        window.d3.version.split(".")[0] == "4"
    ){
        return {
            normal: myProgressBar,
            d3: myD3ProgressBar
        };
    }
    else {
        return {
            normal: myProgressBar
        }
    }
};